function submitFeedback(){
    var data = $('#feedback_form').serializeArray().reduce(function(obj, item) {
        obj[item.name] = item.value;
        return obj;
    }, {});
    $.post("http://localhost:3001/api/add-feedback",
    {
      feedback:data
    },
    function(data){
      if(data.status){
        $('#error-div').css("display","none");
        $('#success-div').css("display","block");
      }else{
        $('#success-div').css("display","none");
        $('#error-div').html(data.message);
        $('#error-div').css("display","block");
      }
    });
}
