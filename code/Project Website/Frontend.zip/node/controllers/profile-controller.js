var connection = require('../config');

module.exports.updateProfile = function (req, res) {
  console.log("Update profile Api called");

  var empty = false;
  var errorMessage = "";
  var user = req.body.user;


  if (user['first_name'] == "") {
    empty = true;
    errorMessage = "please provide first name"
  } else if (user['last_name'] == "") {
    empty = true;
    errorMessage = "please provide last name"
  } else if (user['email'] == "") {
    empty = true;
    errorMessage = "please provide email"
  }

  if (empty) {
    res.json({
      status: false,
      message: errorMessage
    })

  } else if (!validateEmail(user["email"])) {
    res.json({
      status: false,
      message: "please provide valid email"
    })

  } else {
    connection.query('SELECT * FROM users WHERE email = ?', [user.email], function (error, results, fields) {
      if (error) {
        console.log("some error ocurred during user fetch", error);
      } else {
        if (results.length > 0) {
          if(results[0].id!=user.id){
            console.log("user already exit");
            res.json({
              status: false,
              message: "email already exists",
              user: user
            })
  
          }
         else {


          connection.query("UPDATE `users` SET `first_name`='" + user.first_name + "',`last_name`='" + user.last_name + "',`email`='" + user.email + "' WHERE id = ?", [user.id], function (error, results, fields) {
            if (error) {
              console.log("some error ocurred during user update", error);
            } else {
              if (results.affectedRows > 0) {

                connection.query('SELECT id,first_name,last_name,email,username FROM users WHERE id = ?', [user.id], function (error, results, fields) {
                  if (error) {
                    res.json({
                      status: false,
                      message: 'error in api, kindly give us feedback on main page about this error'
                    })
                  } else {

                    if (results.length > 0) {
                      res.json({
                        status: true,
                        message: 'CHANGES SAVED',
                        user: results[0]
                      })

                    } else {
                      res.json({
                        status: false,
                        message: 'changes not saved',
                        user: user
                      })
                    }
                  }
                });
              }
            }
          });

        }}
      }
    });
  }
}
function validateEmail(email) {
  const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  console.log("checking email")
  return re.test(email);
}