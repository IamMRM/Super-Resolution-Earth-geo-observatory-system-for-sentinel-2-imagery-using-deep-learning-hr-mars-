var connection = require('../config');
var Cryptr = require('cryptr');
cryptr = new Cryptr('myTotalySecretKey');

module.exports.updatePassword=function(req,res){
  console.log("Update password Api called");
    
  var empty=false;
  var errorMessage="";  
  var updatePassword=req.body.updatePassword;


  if(updatePassword['old_password']==""){
      empty=true;
      errorMessage="please provide old password"  
  }else if(updatePassword['new_password']==""){
    empty=true;
    errorMessage="please provide new password"  
}else if(updatePassword['confirm_password']==""){
  empty=true;
  errorMessage="please provide confirm password"  
}else if(updatePassword['confirm_password']!=updatePassword['new_password']){
  empty=true;
  errorMessage="confirm password does not match"  
}

if(empty){
  res.json({
    status:false,
    message:errorMessage
})

}else {

  connection.query("Select `password` from users WHERE id = ?",[updatePassword.id], function (error, results, fields) {
    if (error) {
      console.log("some error ocurred during user update",error);
    }else{
      if(results.length>0)
{
  if(updatePassword.old_password==cryptr.decrypt(results[0].password)){
    updatePassword.new_password = cryptr.encrypt(updatePassword.new_password);
  connection.query("UPDATE `users` SET `password`='"+updatePassword.new_password+"' WHERE id = ?",[updatePassword.id], function (error, results, fields) {
    if (error) {
      console.log("some error ocurred during user update",error);
    }else{
      if(results.affectedRows>0)
{
        res.json({
          status:true,
          message:'CHANGES SAVED'
      })
  
      }
    }
  });

  }else{
    res.json({
      status:false,
      message:'old password does not match'
  })
  }

}}});
  
}
    
    }
function validateEmail(email) {
  const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  console.log("checking email")
  return re.test(email);
}