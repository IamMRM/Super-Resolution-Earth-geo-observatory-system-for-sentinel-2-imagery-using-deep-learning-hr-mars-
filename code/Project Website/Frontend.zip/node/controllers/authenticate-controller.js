var Cryptr = require('cryptr');
cryptr = new Cryptr('myTotalySecretKey');

var connection = require('./../config');
module.exports.authenticate=function(req,res){
    console.log("Login Api called");
    var userInfo=req.body.userInfo;
    connection.query('SELECT * FROM users WHERE email = ?',[userInfo.email], function (error, results, fields) {
      if (error) {
          res.json({
            status:false,
            message:'error in login api, kindly give us feedback on main page about this error'
            })
      }else{
		  
        if(results.length >0){
	          decryptedString = cryptr.decrypt(results[0].password);
            if(userInfo.password==decryptedString){
                res.json({
                    data:{
                        id:results[0].id,
                        first_name:results[0].first_name,
                        last_name:results[0].last_name,
                        username:results[0].username,
                        email:results[0].email
                    },
                    status:true,
                    message:'successfully authenticated'
                })
            }else{
                res.json({
                  status:false,
                  message:"incorrect email or password"
                 });
            }
         
        }
        else{
          res.json({
            status:false,    
            message:"email does not exits"
          });
        }
      }
    });
}