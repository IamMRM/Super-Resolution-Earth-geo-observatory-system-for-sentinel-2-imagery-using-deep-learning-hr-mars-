var Cryptr = require('cryptr');
var express = require("express");
var connection = require('../config');
cryptr = new Cryptr('myTotalySecretKey');

module.exports.adddFeedback = function (req, res) {
  console.log("Add feedback Api called");

  var empty = false;
  var errorMessage = "";
  var feedback = req.body.feedback;
 

  if (feedback['name'] == "") {
    empty = true;
    errorMessage = "please provide name"
  } else if (feedback['email'] == "") {
    empty = true;
    errorMessage = "please provide email"
  } else if (feedback['subject'] == "") {
    empty = true;
    errorMessage = "please provide subject"
  } else if (feedback['message'] == "") {
    empty = true;
    errorMessage = "please provide message"
  }

  if (empty) {
    res.json({
      status: false,
      message: errorMessage
    })

  } else if (!validateEmail(feedback["email"])) {
    res.json({
      status: false,
      message: "please provide valid email"
    })

  } else {


    connection.query('INSERT INTO feedback SET ?', feedback, function (error, results, fields) {
      if (error) {
        console.log("feedback=>", error)
        res.json({
          status: false,
          message: 'there are some error with query'
        })
      } else {
          res.json({
            status: true,
            user: results[0],
            message: 'feedback has be submitted sucessfully'
          });
      }
    });



  }
}

function validateEmail(email) {
  const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  console.log("checking email")
  return re.test(email);
}