var express=require("express");
var bodyParser=require('body-parser');

var connection = require('./config');
var app = express();
var cors = require('cors')
app.use(cors())
var authenticateController=require('./controllers/authenticate-controller');
var registerController=require('./controllers/register-controller');
var profileController=require('./controllers/profile-controller');
var passwordController=require('./controllers/password-controller');
var feedbackController=require('./controllers/feedback-controller');


app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

/* route to handle login and registration */
app.post('/api/register',registerController.register);
app.post('/api/authenticate',authenticateController.authenticate);
app.post('/api/update-profile',profileController.updateProfile);
app.post('/api/update-password',passwordController.updatePassword);
app.post('/api/add-feedback',feedbackController.adddFeedback);


console.log(authenticateController);
app.listen(3001);