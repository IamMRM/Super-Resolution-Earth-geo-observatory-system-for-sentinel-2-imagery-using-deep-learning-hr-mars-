export const OurColors = {
    primary: '#086788'
    ,
    tertiary: '#BAE8E8',
    secondary: '#E3F6F5',
    button: {
        highlight: '#FFD803'
    },
    paragraph: {
        default: '#2D334A',
    },

    background: '#FFFFFE',
    headlineStrokeButtonText: '#272343',


    success: '#43B02A'

}