export const MethodSteps={
    stepOne:`First part is to generate vocabulary from image pixels that will form clusters of colors from all
    dataset. For this purpose, the pixels of all datasets are loaded and split into 50 clusters
    (experimental value) by using k-means clustering algorithm, so that the pixels with similar type
    of colors can be treated as single and it will cater some minor differences or errors in satellite
    images (may have been caused due to random noise, clouds, season change, intra-class
    variations) for the same classes as similar or closed colors will belong to a same single cluster.`,
    stepTwo:`Now, we divide the image into segments so that every segment or cluster of image can be
    assigned a same single high-resolution class label, similar to patch wise classification but here
    patches are non-regular as in the form of clusters, and we obtain segmentation results (Note that
    this clustering is within a single image unlike the first one). This is achieved by applying k-
    means clustering algorithm for 20 clusters (because we have 10 class labels so an image cannot
    have more than 10 type of classes in its high-res image and 20 is set to avoid large cluster size).`,
    stepThree:`This parts generates the histogram for each cluster which is used as feature for training and a
    class will be predicted for whole cluster based on the normalized histogram values. By using
    each pixel value belonging to same image segment as generated in previous step, we generate
    histogram of code book / visual words (generated in first step). This histogram is treated as
    feature value for whole cluster.`,
    stepFour:`Obtaining the histogram feature values for each segment, we also calculate class label assigned
    to particular cluster by taking a label value which is most repeated in segment’s pixels. This set
    of histograms and its corresponding class labels are dataset that we use for training our classifier.
    We used Random Forest Classifier having 1000 estimators of decision trees (as the algorithm is
    based on ensemble learning).`,
    stepFive:`Firstly, the input image is segmented into 20 patches (similar to what we did in training phase)
    and for each segment we calculate the histogram by passing its pixel values to vocabulary and
    then the final histogram for each cluster is sent to model to get predicted class label. Class label
    is assigned to all pixels of the segment to its corresponding pixel location, by this we will get the
    final high-resolution land cover map.`
}