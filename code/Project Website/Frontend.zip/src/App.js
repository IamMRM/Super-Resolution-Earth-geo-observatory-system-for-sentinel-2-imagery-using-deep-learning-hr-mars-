import React from 'react';
import './App.css';
import { Route, BrowserRouter } from 'react-router-dom';
import LandingPageTemp from './pages/landingPagetemp';
import HomePage from './pages/home';
import LandingPage from './pages/landingPage';
function App() {
  return (
    <BrowserRouter>
    <div className="App" >
    <Route exact path="/"  component={LandingPage}/>
    <Route exact path="/map" component={HomePage} />
    <Route exact path="/temp" component={LandingPageTemp} / >
        </div>
    </BrowserRouter>
  );
}

export default App;
