import React, { Component } from "react";
import {htmlCode} from "./html";

var template = { __html: htmlCode };

class LandingPage extends Component {
  render() {
    return (
      <div >
        <span dangerouslySetInnerHTML={template} />
      </div>
    );
  }
}
export default LandingPage;