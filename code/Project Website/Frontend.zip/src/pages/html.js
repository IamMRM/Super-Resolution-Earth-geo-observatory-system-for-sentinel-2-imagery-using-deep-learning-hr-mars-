import {MethodSteps} from '../res/stepData'
export const htmlCode =`
<!DOCTYPE html>
<html lang="en">


<body>

  <!-- ======= Top Bar ======= -->
  <div id="topbar" class="d-none d-lg-flex align-items-center fixed-top ">
    <div class="container d-flex">
      <div class="contact-info mr-auto">
        <i class="icofont-envelope"></i> <a href="mailto:hr.mars2020@gmail.com">hr.mars2020@gmail.com</a>
        <i class="icofont-phone"></i> +92 312 1515 110
      </div>
      <div class="social-links">
        <a href="#" class="twitter"><i class="icofont-twitter"></i></a>
        <a href="#" class="facebook"><i class="icofont-facebook"></i></a>
        <a href="#" class="instagram"><i class="icofont-instagram"></i></a>
        <a href="#" class="skype"><i class="icofont-skype"></i></a>
        <a href="#" class="linkedin"><i class="icofont-linkedin"></i></i></a>
      </div>
    </div>
  </div>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center">

      <h1 class="logo mr-auto logo_class" ><a href="/">HR-MARS</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo mr-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="/">Home</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="#services">Features</a></li>
          <li><a href="#cta">Land Cover</a></li>
          <li><a href="#team">Team</a></li>
          <li><a href="#contact">Contact</a></li>

        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container position-relative" data-aos="fade-up" data-aos-delay="500">
      <h1>Welcome to HR-MARS</h1>
      <h2>A platform for Geo-information and Land Covers in High Resolution</h2>
      <a href="#about" class="btn-get-started scrollto">Get Started</a>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="row">
          <div class="col-lg-12 pt-4 pt-lg-0 order-2 order-lg-1 content" data-aos="fade-right">
          <div class="section-title">
          <span>Why we choose this project?</span>
          <h2>Why we choose this project?</h2>
          <p>Watch this video for understanding importance of this project</p>
        </div>

            <iframe width="100%" height="460"
            src="https://www.youtube.com/embed/dDC36NYsW1s">
            </iframe>
            </div>
        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= How it works Section ======= -->
    <section id="how-work" class="why-us">
      <div class="container">
      <div class="section-title">
          <span>How It works</span>
          <h2>How It works</h2>
          <p>Our Land Cover generating system is working in five steps</p>
        </div>

        <div class="row">

          <div class="col-lg-6" data-aos="fade-up">
            <div class="box">
              <span>01</span>
              <h4>Vocabulary Generator</h4>
              <p>`+MethodSteps.stepOne+`</p>
            </div>
          </div>

          <div class="col-lg-6 mt-6 mt-lg-0" data-aos="fade-up" data-aos-delay="150">
            <div class="box">
              <span>02</span>
              <h4>Image segments</h4>
              <p>`+MethodSteps.stepTwo+`</p>
            </div>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="300">
            <div class="box">
              <span>03</span>
              <h4>Histogram Generation</h4>
              <p>`+MethodSteps.stepThree+`</p>
            </div>
          </div>


          <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="300">
          <div class="box">
            <span>04</span>
            <h4>Model Training</h4>
            <p>`+MethodSteps.stepFour+`</p>
          </div>
        </div>


        <div class="col-lg-4 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="300">
          <div class="box">
            <span>05</span>
            <h4>Model Prediction</h4>
            <p>`+MethodSteps.stepFive+`</p>
          </div>
        </div>


        </div>

      </div>
    </section><!-- End Why Us Section -->

    
    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container">

        <div class="section-title">
          <span>Features</span>
          <h2>you can</h2>
          <p>These task can be perfomed thorugh website</p>
        </div>

        <div class="row">
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="fade-up">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-map"></i></div>
              <h4><a href="">Choose any Location </a></h4>
              <p>You can choose any location mark from Google map</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="fade-up" data-aos-delay="150">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-landscape"></i></div>
              <h4><a href="">Low Resolution Land Cover</a></h4>
              <p>You can get low resolution land cover of the location</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="300">
            <div class="icon-box">
              <div class="icon"><i class="bx bxs-landscape"></i></div>
              <h4><a href="">High Resolution Land Cover</a></h4>
              <p>You can get high resolution land cover of the location</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="fade-up" data-aos-delay="450">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-info-circle"></i></div>
              <h4><a href="">Statistics about Low Resolution</a></h4>
              <p>You can get statistics information of different materials on that surface through low resolution land cover</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="fade-up" data-aos-delay="600">
            <div class="icon-box">
              <div class="icon"><i class="bx bxs-info-circle"></i></div>
              <h4><a href="">Statistics about High Resolution</a></h4>
              <p>You can get statistics information of different materials on that surface through high resolution land cover</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="fade-up" data-aos-delay="750">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-download"></i></div>
              <h4><a href="">Download</a></h4>
              <p>You can download images of land covers of both resolutions</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->

    <!-- ======= Cta Section ======= -->
    <section id="cta" class="cta">
      <div class="container" data-aos="zoom-in">

        <div class="text-center">
          <h3>See Land Cover</h3>
          <p>You will be redirected to Google map page. Where you can see land cover of any specific location by clicking marks on Google map</p>
          <a class="cta-btn" href="/map">Go to Google Map</a>
        </div>

      </div>
    </section><!-- End Cta Section -->
	
	    <!-- ======= Team Section ======= -->
    <section id="team" class="team">
      <div class="container">

        <div class="section-title">
          <span>Team</span>
          <h2>Team</h2>
          <p></p>
        </div>

        <div class="row">
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in">
            <div class="member">
              <img src="assets/img/team/team-2.jpg" alt="">
              <h4>Awais Latif</h4>
              <span>SEECS, NUST</span>
              <div class="social">
                <a href=""><i class="icofont-facebook"></i></a>
                <a href=""><i class="icofont-instagram"></i></a>
                <a href=""><i class="icofont-linkedin"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in">
            <div class="member">
              <img src="assets/img/team/team-3.jpg" alt="">
              <h4>Abdul Razzaque Jawad</h4>
              <span>SEECS, NUST</span>
              <div class="social">
                <a href=""><i class="icofont-facebook"></i></a>
                <a href=""><i class="icofont-instagram"></i></a>
                <a href=""><i class="icofont-linkedin"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in">
            <div class="member">
              <img src="assets/img/team/team-1.jpg" alt="">
              <h4>Mohammad Roshan Mughees</h4>
              <span>SEECS, NUST</span>
              <div class="social">
                <a href=""><i class="icofont-facebook"></i></a>
                <a href=""><i class="icofont-instagram"></i></a>
                <a href=""><i class="icofont-linkedin"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-12 col-md-12 text-center"><h2>Advisors</h2></div>
          <div class="col-lg-2 col-md-0"></div>

          <div class="col-lg-4 col-md-6 align-items-stretch" data-aos="zoom-in">
            <div class="member">
              <img src="assets/img/team/team-4.jpeg" alt="">
              <h4>Dr Faisal Shafait</h4>
              <span>SEECS, NUST</span>
              <div class="social">
                <a href=""><i class="icofont-facebook"></i></a>
                <a href=""><i class="icofont-linkedin"></i></a>
              </div>
            </div>
          </div>
          
          <div class="col-lg-4 col-md-6 align-items-stretch" data-aos="zoom-in">
            <div class="member">
              <img src="assets/img/team/team-5.jpeg" alt="">
              <h4>Dr Muhammad Shahzad</h4>
              <span>SEECS, NUST</span>
              <div class="social">
                <a href=""><i class="icofont-facebook"></i></a>
                <a href=""><i class="icofont-linkedin"></i></a>
              </div>
            </div>
          </div>


        </div>

      </div>
    </section><!-- End Team Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title">
          <span>Contact</span>
          <h2>Contact</h2>
          <p>Contact information are given below</p>
        </div>

        <div class="row" data-aos="fade-up">
          <div class="col-lg-6">
            <div class="info-box mb-4">
              <i class="bx bx-map"></i>
              <h3>Our Address</h3>
              <p>NUST H12, Islamabad, Pakistan</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="info-box  mb-4">
              <i class="bx bx-envelope"></i>
              <h3>Email Us</h3>
              <p>hr.mars2020@gmail.com</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="info-box  mb-4">
              <i class="bx bx-phone-call"></i>
              <h3>Call Us</h3>
              <p>+92 312 1515 110</p>
            </div>
          </div>

        </div>

        <div class="row" data-aos="fade-up">

          <div class="col-lg-12">
          <p>Write Us feedback Here</p>
            <form id="feedback_form" class="php-email-form">
              <div class="form-row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                  <div class="validate"></div>
                </div>
                <div class="col-md-6 form-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
                  <div class="validate"></div>
                </div>
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
                <div class="validate"></div>
              </div>
              <div class="form-group">
                <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                <div class="validate"></div>
              </div>
              <div class="mb-3">
                <div class="error-message" id="error-div"></div>
                <div class="sent-message" id="success-div">Your message has been sent. Thank you!</div>
              </div>
              
            </form>
            <div class="text-center"><button class="btn-modal" onclick="submitFeedback()" type="submit">Send Message</button></div>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
 
 
    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>HR-MARS</span></strong>. All Rights Reserved
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>
  
</body>

</html>
`