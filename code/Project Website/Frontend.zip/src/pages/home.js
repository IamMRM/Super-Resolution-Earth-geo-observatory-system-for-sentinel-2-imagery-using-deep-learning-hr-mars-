import React,{Component} from 'react';
import Map from '../components/Map';
import TopBarComponent from '../components/TopBar/MainTopBar/TopBar.component';
class HomePage extends Component {
    state = {
      login:this.props.location.state ? this.props.location.state.data.status:false,
      user:this.props.location.state ? this.props.location.state.data.data:{},
    }
    render() { 
      console.log(this.props.location);
      
        return (<div style={{ height: "100vh" }}>
        <TopBarComponent login={this.state.login} name={this.state.user.first_name+" "+this.state.user.last_name}></TopBarComponent>
        <Map
          center={{ lat: 30.154424, lng: 48.112116 }}
          height="93vh"
          zoom={10.4}
        />
      </div>);
    }
}
 
export default HomePage;