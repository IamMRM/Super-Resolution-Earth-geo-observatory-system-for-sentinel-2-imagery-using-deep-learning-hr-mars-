import React,{Component} from 'react';
import Paper from '@material-ui/core/Paper';
import { Grid, Typography,Box } from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';
import { Link } from "react-router-dom";
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Methology from '../res/metho.png'
import {MethodSteps} from '../res/stepData';
import Badge from '@material-ui/core/Badge';
import AwaisPic from '../res/awais.jpg';
import AlternateEmailIcon from '@material-ui/icons/AlternateEmail';
const MainColor="#FFf"
const ContColor="#000"
const backgroundColor="#3399CC"
//3399CC
const useStyles = (theme) => ({
    menuLink:{
        textShadow: "5px 5px 10px #000",
        paddingRight:"30px",fontSize:"20px",textDecoration:"none",color:MainColor,fontFamily:"GothamBook"},
    logo:{
        textShadow: "5px 5px 10px #000",
        color:MainColor,fontFamily:"Logo",fontSize:"50px",
        "-webkit-transition": "color 1s", /* For Safari 3.0 to 6.0 */
        transition: "color 1s", /* For modern browsers */
        "& : hover":{
            color: "#000"
        }
    },
    methodCard:{color:"#FFF",padding:"20px",backgroundColor:MainColor,borderRadius:"0px 40px"},
    methodTitle:{color:ContColor,fontFamily:"GothamBook",fontWeight:"Bold",fontSize:"30px"},
    methodDescription:{color:ContColor,fontFamily:"GothamBook",fontSize:"20px"},
    root: {
        maxWidth: 345,
        margin:"auto",
        backgroundColor:"#FFF",
        //color:"#fff",
        //boxShadow: "5px 5px 10px #000"
      },
      media: {
        height: 140,
      },
      profileImage:{
        borderRadius:"100px",
        width:"200px",
        height:"200px",
        //boxShadow: "5px 5px 20px"
      },
  });
  

  const StyledBadge = withStyles((theme) => ({
    badge: {
        width:"100px",
        height:"100px",
        fontSize:"40px",
        borderRadius:"50px",
        backgroundColor:"#000"
    },
  }))(Badge);
class LandingPageTemp extends Component {
    state = {
    }

    MediaCard=(imgUrl,name)=> {
        const {classes} = this.props;
      
        return (
          <Card className={classes.root}>
            <CardActionArea>
                <Box style={{padding:"50px 0px 10px 0px"}}>
                    <img src={imgUrl} className={classes.profileImage}></img>
                </Box>
              <CardContent>
                <Typography style={{fontFamily:"GothamBook",fontWeight:"Bold"}} variant="h5" component="h2">
                  {name}
                </Typography>
                <Typography color="textSecondary" style={{fontFamily:"GothamBook",fontWeight:"Bold"}} gutterBottom variant="h6" component="p">
                  NUST
                </Typography>

                <Typography variant="body2"  component="p" style={{padding:"5%",fontFamily:"GothamBook"}}>
                  Lizards are a widespread group of squamate reptiles, with over 6,000 species, ranging
                  across all continents except Antarctica
                </Typography>
              </CardContent>
            </CardActionArea>
            <CardActions>
            </CardActions>
          </Card>
        );
      }
    
    MethodPart=(title,description,classes)=>{
        return(
        <Paper className={classes.methodCard} elevation={4}>
    
        <Typography className={classes.methodTitle}>{title}</Typography>
    
        <Typography className={classes.methodDescription}>{description}</Typography>
    </Paper>
        )
    
    }
    render() { 
        const {classes}=this.props;
        return (<div style={{backgroundColor:backgroundColor }}>
            <Grid container xs={12}>
            <Grid container item xs={12} style={{paddingTop:"20px"}}>
                <Grid item xs={3}>
                <Typography className={classes.logo}>HR-MARS</Typography>
                </Grid>
                <Grid item xs={9} container justify="flex-end" alignItems="center">
                <Link to='/home' className={classes.menuLink}>
                        Home
                </Link>
                
                <Link to='/login' className={classes.menuLink}>
                    Sign in
                </Link>
                <Link to='/signup' className={classes.menuLink}>
                        Sign Up
                </Link>
                
                </Grid>

            </Grid>
            <Grid item xs={12}>
                <Typography style={{color:MainColor,paddingTop:"20px",fontFamily:"Logo",fontSize:"40px"}}>How It Works</Typography></Grid>
                <Grid item xs={9} style={{padding:"2% 10%"}}>
                    <StyledBadge badgeContent={1} color="primary"  
                    anchorOrigin={{
                        vertical: 'top',
                        horizontal: 'left',
                    }}
                    className={classes.badge}>
                {this.MethodPart("Vocabulary Generator",MethodSteps.stepOne,classes)}
                </StyledBadge>

                </Grid>
                <Grid item xs={3}>
                </Grid>
                <Grid item xs={3} container alignItems="center" justify="center">

                </Grid>
                <Grid item xs={9} style={{padding:"2% 10%"}}>
                <StyledBadge badgeContent={2} color="primary"  
                    anchorOrigin={{
                        vertical: 'top',
                        horizontal: 'right',
                    }}
                    className={classes.badge}>
                {this.MethodPart("Image segments",MethodSteps.stepTwo,classes)}
                </StyledBadge>
                </Grid>
                <Grid item xs={9} style={{padding:"2% 10%"}}>
                <StyledBadge badgeContent={3} color="primary"  
                    anchorOrigin={{
                        vertical: 'top',
                        horizontal: 'left',
                    }}
                    className={classes.badge}>
                
                {this.MethodPart("Histogram Generation",MethodSteps.stepThree,classes)}
                </StyledBadge>
                </Grid>
                <Grid item xs={3}></Grid>
                <Grid item xs={3}></Grid>
                <Grid item xs={9} style={{padding:"2% 10%"}}>
                <StyledBadge badgeContent={4} color="primary"  
                    anchorOrigin={{
                        vertical: 'top',
                        horizontal: 'right',
                    }}
                    className={classes.badge}>
                
                {this.MethodPart("Model Training",MethodSteps.stepFour,classes)}
                </StyledBadge>
                </Grid>
                <Grid item xs={9} style={{padding:"2% 10%"}}>
                <StyledBadge badgeContent={5} color="primary"  
                    anchorOrigin={{
                        vertical: 'top',
                        horizontal: 'left',
                    }}
                    className={classes.badge}>
                
                {this.MethodPart("Model Prediction",MethodSteps.stepFive,classes)}
                </StyledBadge>
                </Grid>
                <Grid item xs={3}></Grid>
            <Grid item xs={12}><Typography style={{color:MainColor,fontFamily:"Logo",fontSize:"30px"}}>Our Process Diagram</Typography></Grid>
                <Grid item xs={12} style={{padding:"2% 10%"}}>
                <Paper style={{color:"#FFF",padding:"20px",backgroundColor:MainColor}} elevation={4}>
                    <img src={Methology} style={{width:"100%"}}/>
                </Paper>
                </Grid>

            </Grid>
                <Grid item xs={12}><Typography style={{color:MainColor,fontFamily:"Logo",fontSize:"30px"}}>Our Team</Typography></Grid>
                    <Grid container item xs={12} style={{padding:"2% 10%"}}>
                    <Grid item xs={4}>
                    {this.MediaCard(AwaisPic,"Awais Latif Khatti")}
                    </Grid>
                    <Grid item xs={4}>
                    {this.MediaCard(AwaisPic,"Awais Latif Khatti")}
                    </Grid>
                    <Grid item xs={4}>
                    {this.MediaCard(AwaisPic,"Awais Latif Khatti")}
                    </Grid>
                    
                </Grid>

                <Grid item xs={12}><Typography style={{color:MainColor,fontFamily:"Logo",fontSize:"30px"}}>Contact us</Typography></Grid>

                <Grid item xs={12} style={{padding:"2% 10%"}}>
                </Grid>

      </div>);
    }
}
 
export default withStyles(useStyles)(LandingPageTemp);