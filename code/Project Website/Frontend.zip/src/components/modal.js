import React from 'react';
import { makeStyles, withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Slide from '@material-ui/core/Slide';
import Typography from '@material-ui/core/Typography';
import Slider from '@material-ui/core/Slider';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import InputBase from '@material-ui/core/InputBase';
import TextField from '@material-ui/core/TextField';
import Paper from '@material-ui/core/Paper';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Box from '@material-ui/core/Box';
import PropTypes from 'prop-types';

const colors = { header: '#000' };

const StyledTableCell = withStyles((theme) => ({
	head: {
		backgroundColor: "#cc1616",
		color: theme.palette.common.white,
		fontFamily: "RalewayRegular"
	},
	body: {
		fontSize: 14
	}
}))(TableCell);

const StyledTableRow = withStyles((theme) => ({
	root: {
		'&:nth-of-type(odd)': {
			backgroundColor: theme.palette.background.default
		}
	}
}))(TableRow);

const StyledTabs = withStyles({
	indicator: {
		display: 'flex',
		justifyContent: 'center',
		backgroundColor: 'transparent',
		'& > span': {
			maxWidth: 80,
			width: '100%',
			backgroundColor: '#cc1616',
		},
	},
})((props) => <Tabs {...props} TabIndicatorProps={{ children: <span /> }} />);

const StyledTab = withStyles((theme) => ({
	root: {
		textTransform: 'none',
		color: '#000',
		fontFamily: "RalewayRegular",
		fontWeight: theme.typography.fontWeightBold,
		fontSize: theme.typography.pxToRem(25),
		marginRight: theme.spacing(1),
		'&:hover': {
			opacity: 1,
			color: "#cc1616"
		},
	},
}))((props) => <Tab disableRipple {...props} />);

function TabPanel(props) {
	const { children, value, index, ...other } = props;

	return (
		<div
			role="tabpanel"
			hidden={value !== index}
			id={`vertical-tabpanel-${index}`}
			aria-labelledby={`vertical-tab-${index}`}
			{...other}
		>
			{value === index && (
				<Box p={3}>
					<Typography>{children}</Typography>
				</Box>
			)}
		</div>
	);
}

TabPanel.propTypes = {
	children: PropTypes.node,
	index: PropTypes.any.isRequired,
	value: PropTypes.any.isRequired,
};

const useStyles = makeStyles((theme) => ({
	formControl: {
		margin: theme.spacing(1),
		minWidth: 250,
		height: '50px',
		width: '100%',
		colors: colors.header
	},
	selectEmpty: {},
	labelColor: {
		color: colors.header
	},
	table: {
		minWidth: 200
	}
}));
const Transition = React.forwardRef(function Transition(props, ref) {
	return <Slide direction="up" ref={ref} {...props} />;
});

export default function SimpleModal(props) {
	const { open, handleClose, data } = props;
	console.log("data key objects=>>>", Object.keys(data.highResolution.classes));
	console.log("data=>>>", typeof data.classes);
	const [value, setValue] = React.useState(0);
	const classes = useStyles();

	const downloadBtn = (file) => {
		return (
			localStorage.getItem("auth") ? <a className="btn-modal" href={file} download="HighResolutionLandCover.png">Download</a> : <div >want to download image? <a href="#modalSignIn" data-toggle="modal" onClick={handleClose}>Sign in</a></div>
		)
	}

	const handleChange = (event, newValue) => {
		setValue(newValue);
	};
	return (
		<Grid container item xs={12} lg={12} style={{ margin: 'unset' }}>
			<div>
				<Dialog
					fullWidth={true}
					maxWidth={'xl'}

					open={open}
					TransitionComponent={Transition}
					keepMounted
					onClose={handleClose}
					aria-labelledby="alert-dialog-slide-title"
					aria-describedby="alert-dialog-slide-description"
				>
					<DialogContent>
						<DialogContent
							id="alert-dialog-slide-description"
							style={{ fontFamily: 'Raleway' }}
						>

							<div style={{ width: '90%', margin: 'auto', textAlign: 'center' }}>
								<Typography variant="h4" style={{ fontFamily: 'Raleway' }}>
									LAND COVER
								</Typography>

								<StyledTabs value={value} onChange={handleChange} aria-label="styled tabs example">
									<StyledTab label="High Resolution" />
									<StyledTab label="Low Resolution" />
								</StyledTabs>
								<TabPanel value={value} index={0}>

									<Grid
										item
										container
										direction="row"
										xs={12}
										md={12}
										alignItems={'center'}
										justify={'center'}
									>

										<Grid item xs={12} md={6} style={{ padding: '2%' }}>
											<img src={data.highResolution.landCoverUrls} style={{ width: '80%', borderRadius: '20px', marginBottom: "10px" }} />
											{downloadBtn(data.highResolution.landCoverUrls)}
										</Grid>
										<Grid item xs={12} md={3}>
											<TableContainer component={Paper}>
												<Table className={classes.table} aria-label="customized table">
													<TableHead>
														<TableRow>
															<StyledTableCell>Class Name</StyledTableCell>
															<StyledTableCell>Percentage</StyledTableCell>
														</TableRow>
													</TableHead>
													<TableBody>
														{Object.keys(data.highResolution.classes).map(key =>
															<StyledTableRow key={key}>
																<StyledTableCell>{key}</StyledTableCell>
																<StyledTableCell>{data.highResolution.classes[key].toFixed(2)}</StyledTableCell>
															</StyledTableRow>
														)}
													</TableBody>
												</Table>
											</TableContainer>
										</Grid>
									</Grid>

								</TabPanel>
								<TabPanel value={value} index={1}>

								<Grid
										item
										container
										direction="row"
										xs={12}
										md={12}
										alignItems={'center'}
										justify={'center'}
									>

										<Grid item xs={12} md={6} style={{ padding: '2%' }}>
											<img src={data.lowResolution.landCoverUrls} style={{ width: '80%', borderRadius: '20px', marginBottom: "10px" }} />
											{downloadBtn(data.lowResolution.landCoverUrls)}
										</Grid>
										<Grid item xs={12} md={3}>
											<TableContainer component={Paper}>
												<Table className={classes.table} aria-label="customized table">
													<TableHead>
														<TableRow>
															<StyledTableCell>Class Name</StyledTableCell>
															<StyledTableCell>Percentage</StyledTableCell>
														</TableRow>
													</TableHead>
													<TableBody>
														{Object.keys(data.lowResolution.classes).map(key =>
															<StyledTableRow key={key}>
																<StyledTableCell>{key}</StyledTableCell>
																<StyledTableCell>{data.lowResolution.classes[key].toFixed(2)}</StyledTableCell>
															</StyledTableRow>
														)}
													</TableBody>
												</Table>
											</TableContainer>
										</Grid>
									</Grid>

								</TabPanel>
							</div>
						</DialogContent>
					</DialogContent>
					<DialogActions>
						<Grid
							container
							xs={12}
							md={12}
							item
							alignItems={'center'}
							justify={'center'}
							style={{ marginBottom: '20px' }}
						>
							<Grid
								item
								xs
								container
								justify="center"
								style={{ paddingRight: '5px' }}
							>
								<button
									onClick={handleClose}
									className="btn-modal"
								>
									Close
								</button>
							</Grid>
						</Grid>
					</DialogActions>
				</Dialog>
			</div>
		</Grid>
	);
}
