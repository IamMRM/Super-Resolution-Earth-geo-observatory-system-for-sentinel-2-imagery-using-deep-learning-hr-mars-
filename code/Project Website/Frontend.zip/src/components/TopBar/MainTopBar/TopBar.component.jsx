import React from "react";
import axios from 'axios';
import CircularProgress from '@material-ui/core/CircularProgress';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Box from '@material-ui/core/Box';
import PropTypes from 'prop-types';
import Typography from '@material-ui/core/Typography';

function TabPanel(props) {
	const { children, value, index, ...other } = props;

	return (
		<div
			role="tabpanel"
			hidden={value !== index}
			id={`vertical-tabpanel-${index}`}
			aria-labelledby={`vertical-tab-${index}`}
			{...other}
		>
			{value === index && (
				<Box p={3}>
					<Typography>{children}</Typography>
				</Box>
			)}
		</div>
	);
}

TabPanel.propTypes = {
	children: PropTypes.node,
	index: PropTypes.any.isRequired,
	value: PropTypes.any.isRequired,
};


class TopBar extends React.Component {

    state = {
        auth:localStorage.getItem("auth")||false,
        error:false,
        loading:false,
        errorMessage:"",
        successMessage:"",
        success:false,
        erroMessagePassword:"",
        loginInfo:{
            email:"",
            password:""
        },
        registerInfo:{
            first_name:"",
            last_name:"",
            email:"",
            password:""
        },
        updatePassword:{
            id:"",
            old_password:"",
            new_password:"",
            confirm_password:""
        },
        value:0
    };

    saveUser=(user)=>{
        this.removeUser();
        localStorage.setItem("user",JSON.stringify(user));
        localStorage.setItem("auth",true);
        const updatePassowrd= this.state.updatePassword;
        updatePassowrd.id=user.id;
        this.setState({registerInfo:user,updatePassowrd});
    }
    removeUser=()=>{
        localStorage.removeItem("user");
        localStorage.removeItem("auth");
    }


      handleLogout=()=>{
        this.removeUser();
        this.setState({auth:false});
      }

      onChangeSignIn=(event)=>{
        this.setState({error:false,erroMessage:""});
        let loginInfo=this.state.loginInfo;
        loginInfo[event.target.name]=event.target.value;
        this.setState({loginInfo});
      }

      onCloseProfileModal=()=>{
        if(localStorage.getItem("auth")){
            const user=JSON.parse(localStorage.getItem("user"));
            const updatePassowrd={
                id:user.id,
                old_password:"",
                new_password:"",
                confirm_password:""
            };
            this.setState({registerInfo:user,updatePassowrd:updatePassowrd,value:0,errorMessage:"",error:false,erroMessagePassword:""});
        }  
      }
      onChangePassword=(event)=>{
        this.setState({error:false,erroMessagePassword:""});
        let updatePassword=this.state.updatePassword;
        updatePassword[event.target.name]=event.target.value;
        if(event.target.name=="confirm_password"){
            if(updatePassword["confirm_password"]!=updatePassword["new_password"]){
                this.setState({error:true,erroMessagePassword:"Please enter same password"});
            }
        }
        this.setState({updatePassword});
      }

      onChangeRegister=(event)=>{
        this.setState({error:false,erroMessage:""});
        let registerInfo=this.state.registerInfo;
        registerInfo[event.target.name]=event.target.value;
        this.setState({registerInfo});
      }
      onSaveAccountClick=(event)=>{
        event.preventDefault();
        const thiss=this;
          console.log(this.state.registerInfo);
          this.setState({error:false,erroMessage:"",success:false,loading:true});
          axios.post('http://localhost:3001/api/update-profile', {
            user:this.state.registerInfo
          })
          .then(function (response) {
            console.log("data",response);
            if(response.data.status){
                thiss.saveUser(response.data.user);
                thiss.setState({success:true,successMessage:response.data.message,loading:false})
            }else{
                thiss.setState({error:true,errorMessage:response.data.message,loading:false})  
            }
      
          })
          .catch(function (error) {
            thiss.setState({error:true,errorMessage:"Changes not saved, try again",loading:false})
            console.log(error);
          });

      }
      onSavePasswordClick=(event)=>{
        event.preventDefault();
        console.log(this.state.updatePassword);
        const thiss=this;
          console.log(this.state.registerInfo);
          this.setState({error:false,erroMessage:"",success:false,loading:true});
          axios.post('http://localhost:3001/api/update-password', {
            updatePassword:this.state.updatePassword
          })
          .then(function (response) {
            console.log("data",response);
            if(response.data.status){
                thiss.setState({error:true,erroMessagePassword:response.data.message,loading:false})
            }else{
                thiss.setState({error:true,erroMessagePassword:response.data.message,loading:false})  
            }
      
          })
          .catch(function (error) {
            thiss.setState({error:true,errorMessage:"Changes not saved, try again",loading:false})
            console.log(error);
          });    
    }
      onSigInClick=(event)=>{
        event.preventDefault();
          console.log("click on sign in")
          var thiss=this;
          this.setState({error:false,erroMessage:"",loading:true});
          console.log("click");
          axios.post('http://localhost:3001/api/authenticate', {
            userInfo:this.state.loginInfo
          })
          .then(function (response) {
            console.log("data",response);
            if(response.data.status){
                thiss.saveUser(response.data.data);
                window.location.href = "/map";
            }else{
                thiss.removeUser();
                thiss.setState({error:true,errorMessage:response.data.message,loading:false})  
            }
      
          })
          .catch(function (error) {
            thiss.removeUser();
            thiss.setState({error:true,errorMessage:"Login failed, try again",loading:false})
            console.log(error);
          });
      
      }
      onRegisterClick=(event)=>{
        event.preventDefault();
        let thiss=this;
        let user = this.state.registerInfo;
        delete user.id;
        user["username"]=user.first_name+user.last_name;
        console.log("user",user);
        this.setState({error:false,erroMessage:"",loading:true});
        axios.post('http://localhost:3001/api/register', {
        user
    })
    .then(function (response) {
      console.log("user registered",response.data);
      if(response.data.status){    
        thiss.saveUser(response.data.user);
        window.location.href="/map";
        }else{
            thiss.removeUser();
            thiss.setState({error:true,errorMessage:response.data.message,loading:false})
      }
    })
    .catch(function (error) {
        thiss.removeUser();
        thiss.setState({error:true,errorMessage:"Registration failed, try again",loading:false})
      console.log(error);
    });

    }


    loginModel=()=>{
        return (          
        <div id="modalSignIn" className="modal fade">
        <div className="modal-dialog modal-login">
            <div className="modal-content">
                <div className="modal-header">				
                    <h4 className="modal-title" style={{fontFamily:"RalewayRegular"}}>Sign In</h4>
                    <button type="button" className="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>
                <div className="modal-body">
                    <form >
                        <div className="form-group">
                            <div className="input-group">
                                <input onChange={this.onChangeSignIn} type="email" className="form-control" name="email" placeholder="Email" required="required"/>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="input-group">
                                <input onChange={this.onChangeSignIn} type="password" className="form-control" name="password" placeholder="Password" required="required"/>
                            </div>
                        </div>
                        <div className="form-group">
                        {this.state.error?<p style={{color:"#cc1616",fontFamily:"RalewayRegular"}} >{this.state.errorMessage}</p>:""}
                        {this.state.loading?<CircularProgress style={{color:"#cc1616"}} size={30} thickness={3} disableShrink />
                            :
                            <button type="submit" onClick={this.onSigInClick} className="btn btn-block btn-lg">Sign In</button>}
                                                   </div>
                    </form>
                </div>
                <div className="modal-footer">Don't have an account? <a href="#modalRegister" data-toggle="modal"><a href="#modalSignIn" data-dismiss="modal">Create one</a></a></div>
            </div>
        </div>
    </div>   
    );
    }


    handleChangeTab=(event, newValue)=>{
        this.setState({value:newValue});
    }
    profileModel=()=>{
        let currentUser=this.state.registerInfo;
        return (          
        <div id="modalProfile" className="modal fade">
        <div className="modal-dialog modal-login" style={{width:"600px"}}>
            <div className="modal-content">
                <div className="modal-header">				
                    <h4 className="modal-title" style={{fontFamily:"RalewayRegular"}}>Profile Settings</h4>
                    <button onClick={this.onCloseProfileModal} type="button" className="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>
                <div className="modal-body">
                <div className="form-group">

                                <Tabs value={this.state.value} onChange={this.handleChangeTab} aria-label="styled tabs example">
									<Tab label="Account" />
									<Tab label="Password" />
								</Tabs>
                    </div>
						<TabPanel value={this.state.value} index={0}>
                        <form >
                        <div className="form-group">
                            <div className="input-group">
                                <span className="lable-profile">First Name</span>
                                <input onChange={this.onChangeRegister} value={currentUser.first_name||""} type="text" className="form-control" name="first_name" placeholder="First Name" required="required"/>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="input-group">
                            <span className="lable-profile">Last Name</span>
                                <input onChange={this.onChangeRegister} value={currentUser.last_name||""} type="text" className="form-control" name="last_name" placeholder="Last Name" required="required"/>
                            </div>
                        </div>

                        <div className="form-group">
                            <div className="input-group">
                            <span className="lable-profile">Email</span>
                                <input onChange={this.onChangeRegister} value={currentUser.email||""} type="email" className="form-control" name="email" placeholder="Email" required="required"/>
                            </div>
                        </div>
                        <br></br>
                        <div className="form-group">
                        {this.state.success?<p style={{color:"#16cc16",fontFamily:"RalewayRegular"}}>{this.state.successMessage}</p>:""}
                        {this.state.error?<p style={{color:"#cc1616",fontFamily:"RalewayRegular"}}>{this.state.errorMessage}</p>:""}
                        {this.state.loading?<CircularProgress style={{color:"#cc1616"}} size={30} thickness={3} disableShrink />
                            : 
                            <button type="submit" onClick={this.onSaveAccountClick} style={{width:"140px"}}  className="btn-get-started btn  btn-block btn-lg">Save</button>}
                        </div>

                    </form>
                        </TabPanel>
                        <TabPanel value={this.state.value} index={1}>
                        <form >
                        <div className="form-group">
                            <div className="input-group">
                            <span className="lable-profile">Current Password</span>
                                <input onChange={this.onChangePassword} type="password" className="form-control" name="old_password" placeholder="Password" required="required"/>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="input-group">
                            <span className="lable-profile">New Password</span>
                                <input onChange={this.onChangePassword} type="password" className="form-control" name="new_password" placeholder="Password" required="required"/>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="input-group">
                            <span className="lable-profile">Confirm Password</span>
                                <input onChange={this.onChangePassword} type="password" className="form-control" name="confirm_password" placeholder="Password" required="required"/>
                            </div>
                        </div>
                        <br></br>
                        <div className="form-group">
                        {this.state.error?<p style={{color:"#cc1616",fontFamily:"RalewayRegular"}}>{this.state.erroMessagePassword}</p>:""}
                        {this.state.loading?<CircularProgress style={{color:"#cc1616"}} size={30} thickness={3} disableShrink />
                            : 
                            <button type="submit" onClick={this.onSavePasswordClick} style={{width:"140px"}}  className="btn-get-started btn  btn-block btn-lg">Save</button>}
                        </div>


                    </form>
                        </TabPanel>
                    
                </div>
                
            </div>
        </div>
    </div>   
    );
    }

    registerModel=()=>{
        return (          
        <div id="modalRegister" className="modal fade">
        <div className="modal-dialog modal-login">
            <div className="modal-content">
                <div className="modal-header">				
                    <h4 className="modal-title" style={{fontFamily:"RalewayRegular"}}>Create New Account</h4>
                    <button type="button" className="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>
                <div className="modal-body">
                    <form >
                        <div className="form-group">
                            <div className="input-group">
                                <input onChange={this.onChangeRegister} type="text" className="form-control" name="first_name" placeholder="First Name" required="required"/>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="input-group">
                                <input onChange={this.onChangeRegister} type="text" className="form-control" name="last_name" placeholder="Last Name" required="required"/>
                            </div>
                        </div>

                        <div className="form-group">
                            <div className="input-group">
                                <input onChange={this.onChangeRegister} type="email" className="form-control" name="email" placeholder="Email" required="required"/>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="input-group">
                                <input onChange={this.onChangeRegister} type="password" className="form-control" name="password" placeholder="Password" required="required"/>
                            </div>
                        </div>
                        <div className="form-group">
                        {this.state.error?<p style={{color:"#cc1616",fontFamily:"RalewayRegular"}}>{this.state.errorMessage}</p>:""}
                        {this.state.loading?<CircularProgress style={{color:"#cc1616"}} size={30} thickness={3} disableShrink />
                            : 
                            <button type="submit" onClick={this.onRegisterClick} className="btn-get-started btn  btn-block btn-lg">Register</button>}
                        </div>
                    </form>
                </div>
                <div className="modal-footer">Already have account? <a href="#modalSignIn" data-toggle="modal"><a href="#modalSignIn" data-dismiss="modal">Sign in</a></a></div>
            </div>
        </div>
    </div>   
    );
    }


    UserAvatar=()=>{
        let user=localStorage.getItem("auth")?JSON.parse(localStorage.getItem("user")):{first_name:"User",last_name:""}
        
        return(
        <li className="drop-down" style={{padding:"10px"}}><a href="" style={{display:"flex",alignItems:"center",justifyContent:"center",textTransform: "capitalize"}}>
        <span className="icon"><i className="bx bx-user-circle" style={{fontSize:"33px",paddingRight:"10px"}}></i></span>{user.first_name+" "+user.last_name}
        </a>
          <ul>
            <li><a href="#modalProfile" data-toggle="modal"  style={{display:"flex",alignItems:"center",justifyContent:"center"}}><i className="bx bx-user" style={{fontSize:"22px",paddingRight:"5px"}}></i> Profile</a></li>
            <li className="divider dropdown-divider"></li>
            <li><a onClick={this.handleLogout} style={{display:"flex",alignItems:"center",justifyContent:"center"}}><i className="bx bx-power-off" style={{fontSize:"22px",paddingRight:"5px"}}></i>Log out</a></li>
          </ul>
        </li>
        );
    }

    SignInButton=()=>{
        return (  
        <><li><a href="#modalSignIn" data-toggle="modal">Sign in</a></li>
        <li><a href="#modalRegister" data-toggle="modal">Register</a></li>     
      </>)
    }



    componentDidMount(){
        if(localStorage.getItem("auth")){
            const user=JSON.parse(localStorage.getItem("user"));
            const updatePassowrd= this.state.updatePassword;
            updatePassowrd.id=user.id;
            this.setState({registerInfo:user,updatePassowrd});
        }
    }

    render() {
        return (
            <div >
            <header id="header" className="fixed-top header-scrolled">
            <div className="container d-flex align-items-center">
        
              <h1 className="logo mr-auto logo_class" ><a href="/">HR-MARS</a></h1>
        
              <nav className="nav-menu d-none d-lg-block">
                <ul>
                  <li ><a href="/">Home</a></li>
                  <li className="active"><a href="#cta">Map</a></li>
                  {localStorage.getItem("auth")?this.UserAvatar():this.SignInButton()}
                </ul>
              </nav>
        
            </div>
          </header>
          {this.loginModel()}
          {this.registerModel()}
          {localStorage.getItem("auth")?this.profileModel():""}
          </div>
        );
    }
}

export default TopBar;
