import React from 'react';
import { withGoogleMap, GoogleMap, withScriptjs, Polygon, Marker } from 'react-google-maps';
import shouldPureComponentUpdate from 'react-pure-render/function';
import SimpleModal from './modal';
import axios from 'axios';
import ProgressModal from './progressModal';

class Map extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			dataServer:[],
			error:false,
			errorMessage:"",
			open: false,
			loading:true,
			mapPosition: {
				lat: this.props.center.lat,
				lng: this.props.center.lng
			},
			data:{
				lowResolution:{
					classes:{
						temp:0
					},
					landCoverUrls:""
				},
				highResolution:{
					classes:{},
					landCoverUrls:""
				}
			}
		};
	}
	/**
	* Get the current address from the default map position and set those values in the state
	*/
	handleClose = () => {
		console.log('close');

		let open = false;
		this.setState({ open }, function () {
			console.log(this.state.open);
		});
	};
	handleOpen = (index) => {
		let data=this.state.data;
		this.setState({loading:true});
		this.setState({error:false,errorMessage:""});

		axios.all([
            axios.get(`http://127.0.0.1:5000/lowlc/`+index,{ responseType:'arraybuffer' }),
			axios.get(`http://127.0.0.1:5000/highlc/`+index,{ responseType:'arraybuffer' }),
			axios.get(`http://127.0.0.1:5000/lowstats/`+index),
			axios.get(`http://127.0.0.1:5000/highstats/`+index)
			
        ])
            .then(axios.spread((lowImageResponse,HighImageResponse,lowStateResponse,HighStateResponse,) => {
				const lowResImage = btoa(
					new Uint8Array(lowImageResponse.data).reduce(
					  (data, byte) => data + String.fromCharCode(byte),
					  '',
					),
				  );
				  const highResImage = btoa(
					new Uint8Array(HighImageResponse.data).reduce(
					  (data, byte) => data + String.fromCharCode(byte),
					  '',
					),
				  );
				  console.log("low result stats=>",lowStateResponse);
				data.lowResolution.classes=lowStateResponse.data.stats;
				data.lowResolution.landCoverUrls="data:;base64," + lowResImage;
				data.highResolution.classes=HighStateResponse.data.stats;
				data.highResolution.landCoverUrls="data:;base64," + highResImage;
				this.setState({data});
				this.setState({loading:false,open:true});	
				
           
            })).catch(error=>{
				//console.log("error=> ",error);
				this.setState({error:true,errorMessage:"Please, click on mark again"});
			})
	};

	shouldComponentUpdate(nextProps, nextState) {
		return false
	}
	componentDidMount() {
		this.setState({error:false,errorMessage:""}); 
		let data=this.state.data;
		axios.get('http://127.0.0.1:5000/locations').then(res=>{
			this.setState({dataServer:res.data,loading:false});
			console.log("result=>",res)
		}).catch(err=>{
			this.setState({error:true,errorMessage:"Please, reload page"});
			console.log("error",err);
		})

		
	}



	/**
	* Component should only update ( meaning re-render ), when the user selects the address, or drags the pin
	*
	* @param nextProps
	* @param nextState
	* @return {boolean}
	*/
	/**
	* This Event triggers when the marker window is closed
	*
	* @param event
	*/
	shouldComponentUpdate = shouldPureComponentUpdate;
	onInfoWindowClose = (event) => { };
	render() {
		const AsyncMap = withScriptjs(
			withGoogleMap((props) => (
				<GoogleMap
					key={'lll'}
					google={this.props.google}
					defaultZoom={this.props.zoom}
					defaultCenter={{
						lat: this.state.mapPosition.lat,
						lng: this.state.mapPosition.lng
					}}
				>

					{this.state.dataServer.map((item, index) => (
						<>
							{console.log("lat",typeof item.coordinates.split(' ')[0],item.coordinates.split(' ')[1])
							/*<Polygon
								key={index}
								path={item.polygon}
								key={1}
								options={{
									strokeColor: '#FF0000',
									strokeOpacity: 0.8,
									strokeWeight: 2,
									fillColor: '#FF0000',
									fillOpacity: 0.35
								}}
							/>*/}

							<Marker
								key={index}
								onClick={() => {
									console.log('click');
									this.handleOpen(index);
								}}

								onMouseOver={() => {
									//this.setState({ info: true })
									console.log('click hover');
									//		this.handleOpen(index);
								}}
								onMouseOut={() => {
									//this.handleClose
									//this.setState({ info: false })
									console.log("mouse out")
								}
								}
								position={{
									lat: parseFloat(item.coordinates.split(' ')[0]),
									lng: parseFloat(item.coordinates.split(' ')[1])
								}}
								/*icon={{
									url: "http://maps.google.com/mapfiles/ms/icons/green-dot.png"								  }}
*/
							></Marker>

						</>

					))}


				</GoogleMap>
			))
		);
		let map;
		if (this.props.center.lat !== undefined) {
			map = (
				<div key={"div1"} style={{marginTop:"55px"}}>
					<AsyncMap
						key={'jjjj'}
						googleMapURL="https://maps.googleapis.com/maps/api/js?key=AIzaSyByZPE4NEkPMdPalilnJ9JjTr8vHIXf7TU&v=3.exp&libraries=geometry,drawing,places"
						loadingElement={<div key={"div2"} style={{ height: `100%` }} />}
						containerElement={<div key={"div3"} style={{ height: this.props.height }} />}
						mapElement={<div key={"div4"} style={{ height: `100%` }} />}
					/>
					<SimpleModal data={this.state.data} handleClose={this.handleClose} open={this.state.open} />
					<ProgressModal 
					error={this.state.error} 
					errorMessage={this.state.errorMessage} 
					open={this.state.loading} 
					handleClose={()=>{this.setState({loading:false})}}
					/>

				</div>
			);
		} else {
			map = <div key={"div6"} style={{ height: this.props.height,marginTop:"55px" }} />;
		}
		return map;
	}
}
export default Map;
