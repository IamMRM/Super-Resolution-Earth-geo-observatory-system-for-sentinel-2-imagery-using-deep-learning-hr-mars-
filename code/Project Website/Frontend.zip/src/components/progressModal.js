import React from 'react';
import { makeStyles, withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import Slide from '@material-ui/core/Slide';
import Typography from '@material-ui/core/Typography';
import Paper from '@material-ui/core/Paper';
import CircularProgress from '@material-ui/core/CircularProgress';
const colors = { header: '#000' };


const useStyles = makeStyles((theme) => ({
    text:{
        padding:'10px'
    },
    error:{
        color: '#cc1616'
    },
    top: {
        color: '#cc1616'
      }
}));
const Transition = React.forwardRef(function Transition(props, ref) {
	return <Slide direction="up" ref={ref} {...props} />;
});

export default function ProgressModal(props) {
	const { open,error,errorMessage,handleClose } = props;
	const classes = useStyles();

	return (
		<Grid container item xs={12} lg={12} style={{ margin: 'unset' }}>
			<div>
				<Dialog
					fullWidth={true}
					maxWidth={'xs'}
                    open={open}
                    onClose={handleClose} 
					TransitionComponent={Transition}
					keepMounted
					aria-labelledby="alert-dialog-slide-title"
					aria-describedby="alert-dialog-slide-description"
				>
					<DialogContent>
						<DialogContent						>
							<div style={{ width: '90%', margin: 'auto', textAlign: 'center' }}>
                                {error?<Typography className={classes.error}>Error</Typography>:<CircularProgress className={classes.top} size={50} thickness={5} disableShrink />}
                                <Typography className={classes.text}>{error?errorMessage:"Please wait..."}</Typography>							
							</div>
						</DialogContent>
					</DialogContent>
				</Dialog>
			</div>
		</Grid>
	);
}
